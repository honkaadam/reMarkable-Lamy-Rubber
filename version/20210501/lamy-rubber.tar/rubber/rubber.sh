#!/bin/bash

workdir=/home/lamyrubber
bindir=${workdir}/bin

if ! echo "$LD_LIBRARY_PATH"|grep -q ${workdir}/lib
then

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/$workdir/lib/

fi

pressednull=0;
pressedone=0;

while [ 1 ]; do
    ${bindir}/evtest --query /dev/input/event1 EV_KEY 331;
    if [ $? -eq 10 ]; then
        if [[ $pressedone = 0 ]]; then
            pressedone=1;
            pressednull=0;
            ${bindir}/evemu-event /dev/input/event1 --type EV_KEY --code BTN_TOOL_RUBBER --value 1 --sync
        fi
    else
        if [[ $pressednull = 0 ]]; then
            pressednull=1;
            pressedone=0;
            ${bindir}/evemu-event /dev/input/event1 --type EV_KEY --code BTN_TOOL_RUBBER --value 0 --sync
        fi
    fi

sleep 0.03

done
